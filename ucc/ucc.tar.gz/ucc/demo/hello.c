
void f(void){
	void k(void);
}
int main(int argc,char * argv[]){	

	return 0;
}

