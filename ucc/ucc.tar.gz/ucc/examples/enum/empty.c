#include <stdio.h>
enum Color{

}a;

int main(){
	
	//printf("%d %d\n",RED,GREEN);
	return 0;
}
