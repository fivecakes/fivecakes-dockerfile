#include <stdio.h>

int a = 3;
int main(){
	switch(a){	
		printf("------------------\n");
	}
	printf("hello world.\n");
	return 0;
}

