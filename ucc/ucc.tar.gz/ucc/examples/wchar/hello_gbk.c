#include <stdio.h>
int main(){
	printf("abc���abc\n");
	return 0;
}

