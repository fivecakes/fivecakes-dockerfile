/**
	see symbol.c
		SaveParameterListTable(void)
 */
void (*f(struct A {int arr[4];} a))
(union A *p1,struct B *p2){
	struct Data{
		int arr[4];
	};
	return 0;
}


int main(){

	return 0;
}

