#include <stdio.h>
/**
	$ make clang
	clang -std=c89 -o hello hello.c && ./hello
	$ make gcc
	gcc -std=c89 -o hello hello.c && ./hello

*/
int main(int argc,char * argv[]){
	for(int i = 0; i < 5; i++){
	}
	
	return 0;
}
