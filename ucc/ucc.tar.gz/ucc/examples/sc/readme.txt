	A demo to show the basic idea of a "Simple C compiler"

(1)On Linux:
make

(2)On Windows
nmake -f Makefile.win

														sheisc@163.com

