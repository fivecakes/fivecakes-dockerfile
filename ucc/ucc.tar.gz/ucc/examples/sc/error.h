#ifndef	ERROR_H
#define	ERROR_H

extern int ErrorCount;
void Error(const char * format,...);
#endif
