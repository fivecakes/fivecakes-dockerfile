{
	int (*f(int,int,int))[4];
	int (*(*fp2)(int,int,int))(int);
	if(c)
		a = f;
	else{
		b = k;
	}

	while(c){
		while(d){
			if(e){
				d = d - 1;
			}
		}
		c = c - 1;
	}
}

